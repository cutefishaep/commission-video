const fs = require('fs');
const path = require('path');

function patchVideo(methodName, inputPath, outputPath) {
    const norm = methodName.toLowerCase().replace(/[-_]/g, '');
    let methodFile = null;

    const methodsDir = path.resolve(__dirname, '..', 'methods');
    if (norm === 'av1sentinelultimate' || norm === 'av1-ultimate' || norm === 'ultimate' || norm === 'av1sentinel') {
        methodFile = path.resolve(methodsDir, 'av1Sentinel-Ultimate.js');
    } else {
        const direct = path.resolve(methodsDir, methodName.endsWith('.js') ? methodName : `${methodName}.js`);
        if (fs.existsSync(direct)) methodFile = direct;
        else throw new Error(`Method "${methodName}" not found.`);
    }

    if (!fs.existsSync(methodFile)) throw new Error(`File not found: ${methodFile}`);
    const mod = require(methodFile);
    const fn = Object.values(mod).find(v => typeof v === 'function');
    if (!fn) throw new Error(`No patch function in ${methodFile}`);

    console.log(`[Patcher] ${path.basename(methodFile)} on ${path.basename(inputPath)}...`);
    fn(inputPath, outputPath);
    console.log(`[Patcher] Done: ${outputPath}`);
}

if (require.main === module) {
    const [method, input, output] = process.argv.slice(2);
    if (!method || !input || !output) {
        console.error('Usage: node patcher.js <method> <input> <output>');
        process.exit(1);
    }
    try { patchVideo(method, input, output); }
    catch (e) { console.error(`[Patcher Error] ${e.message}`); process.exit(1); }
}

module.exports = { patchVideo };
