"""Cookie loader for RawTik Lite."""
from pathlib import Path
import json, sys

ENV_PATH = Path(".env")

def parse_raw_cookie_string(cookie_str):
    cookie_str = cookie_str.strip()
    if cookie_str.startswith("[") or cookie_str.startswith("{"):
        try:
            data = json.loads(cookie_str)
            return data if isinstance(data, list) else [data]
        except Exception: pass
    cookies = []
    for line in cookie_str.splitlines():
        line = line.strip()
        if not line or line.startswith("#"): continue
        parts = line.split("\t")
        if len(parts) >= 7:
            cookies.append({"domain": parts[0], "path": parts[2],
                            "secure": parts[3].lower() == "true",
                            "expires": int(parts[4]) if parts[4].isdigit() else -1,
                            "name": parts[5], "value": parts[6]})
    if cookies: return cookies
    if ";" in cookie_str or "=" in cookie_str:
        for p in cookie_str.split(";"):
            p = p.strip()
            if "=" in p:
                n, v = p.split("=", 1)
                cookies.append({"name": n.strip(), "value": v.strip(),
                                "domain": ".tiktok.com", "path": "/", "secure": True})
        if cookies: return cookies
    raise ValueError("Cookie format not recognized.")

def load_or_prompt_cookie():
    cookie_raw = None
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("TIKTOK_COOKIE="):
                cookie_raw = line[len("TIKTOK_COOKIE="):].strip()
    if not cookie_raw:
        print("\n[Auth] TikTok cookie not configured in .env.")
        print("[Auth] Paste one of:")
        print("  - JSON array: [{\"name\":...,\"value\":...}]")
        print("  - String: sessionid=xxx; sid_guard=yyy; ...")
        u = input("Masukkan cookie TikTok: ").strip()
        if not u:
            print("[Auth Error] Cookie required."); sys.exit(1)
        cookie_raw = u
        ENV_PATH.write_text(f"TIKTOK_ACCOUNT=cutefishaep\nTIKTOK_COOKIE=\"{cookie_raw}\"\n", encoding="utf-8")
    return parse_raw_cookie_string(cookie_raw)
