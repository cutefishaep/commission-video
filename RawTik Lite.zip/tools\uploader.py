"""RawTik Lite uploader - Single Chrome pipeline: upload -> review -> CDN analyze -> delete."""
import json, re, sys, time
from pathlib import Path
from playwright.sync_api import sync_playwright
from tools.analyze import analyze_tiktok_url
from tools.config import load_or_prompt_cookie, parse_raw_cookie_string

UPLOAD_URL = "https://www.tiktok.com/tiktokstudio/upload?from=upload&lang=en"

def _log(m):
    sys.stdout.write(m + "\n"); sys.stdout.flush()

def _normalize(cookies):
    out = []
    for c in cookies or []:
        c = dict(c)
        if c.get("sameSite") not in ("Strict", "Lax", "None"): c["sameSite"] = "Lax"
        if c.get("expires") in (None, -1): c.pop("expires", None)
        out.append(c)
    return out

def _extract_id(href):
    m = re.search(r"/video/(\d+)", href or "")
    return m.group(1) if m else ""

def _hrefs(page):
    try:
        return page.eval_on_selector_all('a[href*="/video/"]', "els => els.map(e => e.getAttribute('href') || '')")
    except Exception: return []

def _dismiss_popups(page, seconds=6):
    end = time.time() + seconds
    while time.time() < end:
        clicked = False
        for label in ("Got it", "Dismiss", "OK"):
            try:
                btn = page.get_by_role("button", name=label, exact=True)
                for i in range(btn.count()):
                    if btn.nth(i).is_visible():
                        btn.nth(i).click(timeout=2000); _log(f"    popup '{label}' closed"); clicked = True; break
            except Exception: pass
        if not clicked:
            try: page.keyboard.press("Escape")
            except Exception: pass
            break
    page.wait_for_timeout(300)

def _visible_button(page, name):
    for loc in (page.get_by_role("button", name=name, exact=True), page.get_by_text(name, exact=True)):
        for i in range(loc.count()):
            try:
                if loc.nth(i).is_visible(): return loc.nth(i)
            except Exception: continue
    return None

def _set_privacy(page):
    _log("[Upload] checking privacy...")
    page.wait_for_timeout(1000)
    cur = None; cur_label = ""
    for label in ("Only me", "Friends", "Private", "Public", "Everyone"):
        el = _visible_button(page, label)
        if el: cur, cur_label = el, label; break
    if cur_label == "Everyone":
        _log("[Upload] privacy already Everyone."); return
    if cur is None:
        labels = []
        for b in page.locator("button").all():
            try:
                if b.is_visible():
                    t = (b.inner_text() or "").strip().replace("\n", " ")
                    if t: labels.append(t[:30])
            except Exception: pass
        _log("[Upload] visible buttons: " + " | ".join(labels[:35]))
        raise RuntimeError("Privacy control not found.")
    cur.click(); page.wait_for_timeout(1000)
    target = None
    for label in ("Everyone", "Public"):
        target = _visible_button(page, label)
        if target: break
    if target is None:
        raise RuntimeError("Everyone option not found.")
    target.click(); page.wait_for_timeout(1200)
    if _visible_button(page, "Everyone") is None:
        raise RuntimeError("Privacy not set to Everyone.")
    _log("[Upload] privacy set to Everyone.")

def _post_button(page):
    return page.get_by_role("button", name="Post", exact=True)

def _wait_post_enabled(page, timeout_s=1200):
    btn = _post_button(page); end = time.time() + timeout_s
    while time.time() < end:
        try:
            if btn.count() > 0:
                b = btn.first
                aria = (b.get_attribute("aria-disabled") or "").lower()
                if b.is_visible() and b.is_enabled() and aria != "true": return b
        except Exception: pass
        page.wait_for_timeout(2000)
    return None

def _upload_video(page, video_path):
    if "login" in page.url.lower():
        raise RuntimeError("Invalid cookie / session expired. Update TIKTOK_COOKIE in .env.")
    try:
        if page.locator("div.VerifyBar___StyledDiv-sc-12zaxoy-0.hRJhHT").count() > 0:
            raise RuntimeError("CAPTCHA appeared - solve manually first.")
    except RuntimeError: raise
    except Exception: pass

    _log("[Upload] inserting video file...")
    page.wait_for_selector('input[type="file"][accept="video/*"]', state="attached", timeout=60000)
    page.set_input_files('input[type="file"][accept="video/*"]', video_path)
    _log("[Upload] file inserted.")
    page.wait_for_selector('div[data-contents="true"]', timeout=120000)
    _dismiss_popups(page, seconds=6)
    try:
        page.locator('div[data-contents="true"]').click()
        page.keyboard.press("Control+A"); page.keyboard.press("Delete")
        _log("[Upload] caption cleared.")
    except Exception: pass
    _set_privacy(page)
    _log("[Upload] waiting for TikTok to process file...")
    post = _wait_post_enabled(page, timeout_s=1200)
    if post is None:
        raise RuntimeError("Post button not enabled after 20 min.")
    _log("[Upload] clicking Post...")
    post.click()
    try:
        now = page.get_by_role("button", name="Post now", exact=True)
        if now.count() > 0 and now.first.is_visible():
            now.first.click(timeout=5000); _log("[Upload] 'Post now' clicked.")
    except Exception: pass
    try:
        page.wait_for_url("**/tiktokstudio/content**", timeout=180000)
        _log("[Upload] posted - content page.")
    except Exception:
        raise RuntimeError("Did not return to content page after Post.")

def _capture_id_from_responses(responses, min_id):
    best = ""
    for resp in responses:
        u = resp.url.lower()
        if not any(k in u for k in ("publish", "post", "item", "aweme", "video", "upload", "content")): continue
        try: data = resp.json()
        except Exception: continue
        def iter_ids(obj):
            keys = {"item_id", "itemid", "aweme_id", "awemeid", "video_id", "videoid"}
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if k.lower() in keys and isinstance(v, (str, int)) and str(v).isdigit() and len(str(v)) >= 18:
                        yield str(v)
                    yield from iter_ids(v)
            elif isinstance(obj, list):
                for x in obj: yield from iter_ids(x)
        for vid in iter_ids(data):
            if int(vid) > int(min_id or 0) and (not best or int(vid) > int(best)):
                best = vid
    return best

def run_pipeline(video_path, cookies_data, max_wait=300, delete=True):
    result = {"url": "", "video_id": "", "stats": None, "deleted": False, "error": ""}
    posted = False
    with sync_playwright() as p:
        _log("[Chrome] opening browser (single Chrome for whole pipeline)...")
        ext_dir = Path("tools/chrome_ext")
        args = ["--disable-blink-features=AutomationControlled", "--no-sandbox", "--disable-infobars"]
        if ext_dir.exists():
            args.extend([f"--disable-extensions-except={ext_dir.resolve()}", f"--load-extension={ext_dir.resolve()}"])
            _log(f"[Chrome] extension loaded: {ext_dir}")
        browser = p.chromium.launch(channel="chrome", headless=False, args=args)
        context = browser.new_context(viewport={"width": 1400, "height": 900}, locale="en-US")
        context.add_cookies(_normalize(cookies_data))
        page = context.new_page()
        api_responses = []
        page.on("response", lambda resp: api_responses.append(resp) if resp.request.resource_type in ("xhr", "fetch") else None)

        try:
            _log("[Chrome] opening TikTok Studio upload...")
            page.goto(UPLOAD_URL, wait_until="domcontentloaded", timeout=60000)
            _log("[Upload] inserting video file...")
            page.wait_for_selector('input[type="file"][accept="video/*"]', state="attached", timeout=60000)
            page.set_input_files('input[type="file"][accept="video/*"]', video_path)
            _log("[Upload] file inserted.")
            page.wait_for_selector('div[data-contents="true"]', timeout=120000)
            _dismiss_popups(page, seconds=6)
            try:
                page.locator('div[data-contents="true"]').click()
                page.keyboard.press("Control+A"); page.keyboard.press("Delete")
                _log("[Upload] caption cleared.")
            except Exception: pass
            _set_privacy(page)
            _log("[Upload] waiting for processing...")
            post = _wait_post_enabled(page, timeout_s=1200)
            if post is None:
                raise RuntimeError("Post button not enabled after 20 min.")
            _log("[Upload] clicking Post...")
            post.click()
            try:
                page.wait_for_url("**/tiktokstudio/content**", timeout=180000)
                _log("[Upload] posted - content page.")
            except Exception:
                raise RuntimeError("Did not return to content page after Post.")

            # Get video ID
            video_id = _capture_id_from_responses(api_responses, 0) or ""
            if not video_id:
                video_id = _wait_for_new_id(page, api_responses, 0, timeout_s=90)
            if not video_id:
                raise RuntimeError("No video ID found.")
            result["video_id"] = video_id
            result["url"] = f"https://www.tiktok.com/@cutefishaep/video/{video_id}"
            _log(f"[Upload] video ID: {video_id}")
            _log(f"[Status] URL: {result['url']}")

            # Wait for review
            _log("[Status] waiting for review...")
            try:
                page.wait_for_function(
                    """() => {
                        const rows = document.querySelectorAll('div.css-153feq8');
                        for (const el of rows) {
                            const fk = Object.keys(el).find(k => k.indexOf('__reactFiber$') === 0);
                            if (!fk) continue;
                            let f = el[fk], d = 0;
                            while (f && d < 40) {
                                const p = f.memoizedProps;
                                if (p && p.item && p.item.item_id) {
                                    const it = p.item;
                                    const ready = String(it.status) !== '141' && Number(it.visibility) === 1;
                                    if (ready && (window.__rtik_hits || 0) >= 2) return true;
                                    if (ready) window.__rtik_hits = (window.__rtik_hits || 0) + 1;
                                    return false;
                                }
                                f = f.return; d += 1;
                            }
                        }
                        return false;
                    }""", polling=1000, timeout=max_wait * 1000)
                _log("[Status] video live / Everyone.")
            except Exception:
                _log("[Status] review timeout (proceeding anyway).")

            # Analyze CDN
            url = result["url"]
            _log("[Analisa] resolving via tikwm...")
            try:
                stats = None
                for i in range(1, 6):
                    _log(f"[Analisa] attempt {i}/5...")
                    try:
                        s = analyze_tiktok_url(url)
                        if s and s.get("width") and s.get("fps"):
                            stats = s; break
                    except Exception: pass
                    if i < 5:
                        _log(f"[Analisa] waiting 6s..."); time.sleep(6)
                result["stats"] = stats
            except Exception as e:
                _log(f"[Analisa] failed: {e}")

            if result["stats"] is None:
                _log("[Analisa] CDN analysis failed.")

            # Delete
            if delete:
                _log("[Hapus] deleting test video...")
                top = _first_row_text(page)
                row = page.locator("div.css-153feq8").first
                _delete_row(page, row, "top row", video_id)
        except Exception as e:
            result["error"] = str(e)
            _log(f"[Pipeline] ERROR: {e}")
            if delete and posted:
                _log("[Pipeline] cleanup: deleting posted video...")
                try:
                    result["deleted"] = _delete_row(page, page.locator("div.css-153feq8").first, "top row", result["video_id"])
                except Exception: pass
        finally:
            if delete and posted and not result.get("deleted") and not result.get("error"):
                try:
                    result["deleted"] = _delete_row(page, page.locator("div.css-153feq8").first, "top row", result["video_id"])
                except Exception: pass
            _log("[Chrome] closing browser.")
            context.close(); browser.close()
    return result

def _wait_for_new_id(page, responses, min_id, timeout_s=90):
    end = time.time() + timeout_s
    while time.time() < end:
        vid = _capture_id_from_responses(responses, min_id)
        if vid:
            _log(f"[Upload] video ID: {vid}")
            return vid
        page.wait_for_timeout(3000)
    return ""

def _first_row_text(page):
    try:
        row = page.locator("div.css-153feq8").first
        if row.count() > 0:
            return (row.inner_text() or "").replace("\n", " ").strip()
    except Exception: pass
    return ""

def _visible_click(locator):
    for i in range(locator.count()):
        try:
            if locator.nth(i).is_visible():
                locator.nth(i).click(); return True
        except Exception: continue
    return False

def _delete_row(page, row, label, video_id=""):
    try:
        row.scroll_into_view_if_needed(); page.wait_for_timeout(500)
        buttons = row.locator("button")
        _log(f"[Hapus] {label}: clicking More...")
        buttons.last.click(); page.wait_for_timeout(1000)
        _log("[Hapus] clicking Delete...")
        if not _visible_click(page.get_by_text("Delete", exact=True)):
            _log("[Hapus] Delete menu not found."); page.keyboard.press("Escape"); return False
        page.wait_for_timeout(1200)
        dialog = page.locator('[role="dialog"]:visible').last
        if dialog.count() == 0:
            dialog = page.locator('[class*="TUXModal"]:visible').last
        confirm = dialog.get_by_role("button", name="Delete", exact=True)
        if confirm.count() == 0:
            confirm = page.get_by_role("button", name="Delete", exact=True)
        if not _visible_click(confirm):
            _log("[Hapus] confirm Delete not found."); page.keyboard.press("Escape"); return False
        end = time.time() + 15
        while time.time() < end:
            if page.locator(f'a[href*="/video/{video_id}"]').count() == 0:
                _log("[Hapus] deleted from list."); return True
            page.wait_for_timeout(300)
        _log("[Hapus] verification failed - video still present."); return False
    except Exception as e:
        _log(f"[Hapus] error: {e}"); return False
