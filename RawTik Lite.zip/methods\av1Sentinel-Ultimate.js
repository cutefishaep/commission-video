const fs = require('fs');
const path = require('path');

function readU32(buf, offset) {
    return buf.readUInt32BE(offset);
}

function makeBox(type, payload) {
    const size = 8 + payload.length;
    const box = Buffer.alloc(size);
    box.writeUInt32BE(size, 0);
    box.write(type, 4, 4, 'ascii');
    payload.copy(box, 8);
    return box;
}

function makeCommentBox(text) {
    const textBuf = Buffer.from(text, 'utf8');
    const payloadSize = 8 + textBuf.length;
    const boxSize = 8 + payloadSize;
    const box = Buffer.alloc(boxSize);
    box.writeUInt32BE(boxSize, 0);
    box[4] = 0xA9; box[5] = 0x63; box[6] = 0x6D; box[7] = 0x74; // '©cmt'
    box.writeUInt32BE(0, 8); // version + flags
    box.writeUInt16BE(0, 12); // language
    box.writeUInt16BE(0, 14); // pre_defined
    textBuf.copy(box, 16);
    return box;
}

function parseBoxes(buf, start = 0, end = buf.length) {
    const boxes = [];
    let off = start;
    while (off + 8 <= end) {
        let size = buf.readUInt32BE(off);
        const type = buf.toString('latin1', off + 4, off + 8);
        let headerSize = 8;
        if (size === 1) {
            size = Number(buf.readBigUInt64BE(off + 8));
            headerSize = 16;
        } else if (size === 0) {
            size = end - off;
        }
        if (size < headerSize || off + size > end) break;
        boxes.push({ type, offset: off, size, headerSize, contentStart: off + headerSize, end: off + size });
        off += size;
    }
    return boxes;
}

function findDeep(buf, start, end, targetType) {
    const boxes = parseBoxes(buf, start, end);
    for (const b of boxes) {
        if (b.type === targetType) return b;
        if (['moov', 'trak', 'mdia', 'minf', 'stbl', 'edts'].includes(b.type)) {
            const sub = findDeep(buf, b.contentStart, b.end, targetType);
            if (sub) return sub;
        }
    }
    return null;
}

/**
 * AV1 Sentinel Ultimate (Sandbox → Work)
 * Kombinasi terbaik dari semua variasi yang berhasil 1080p60 PASS.
 * Prinsip: SEMANGKIT MANIPULASI SECARA MINIMAL — semakin sedikit perubahan,
 * semakin tidak terdeteksi sebagai "file dimanipulasi" oleh server ByteDance.
 *
 * Fitur:
 * 1. Pure 2-track (video + audio), TIDAK ada Track 3 dummy audio trap.
 * 2. mvhd Version 1 (64-bit), timescale 48000, durasi infinite.
 * 3. tkhd & elst rescale dari original timescale → 48000 (A/V sync exact).
 * 4. Video stts +1 zero-delta sample (minimum untuk validitas stbl).
 * 5. Video stsz +1 sample size 8.
 * 6. Video stsc +1 chunk.
 * 7. Video stco +1 chunk dengan anchor di DALAM mdat (tidak ada byte di luar mdat).
 * 8. TIDAK ada ctts injection (ctts justru bisa terdeteksi manipulasi komposisi).
 * 9. TIDAK ada out-mdat-trap / trailing bytes di luar mdat.
 * 10. FTYP tidak diubah.
 * 11. Retain udta box asli.
 * 12. Early break saat offset chunk sudah konvergen.
 * 13. Output murni: ftyp → moov → mdat (ISO-compliant, tidak ada byte sisa).
 */
function patchAv1SentinelUltimateBuffer(inputBuffer) {
    const buf = Buffer.isBuffer(inputBuffer)
        ? inputBuffer
        : Buffer.from(inputBuffer.buffer, inputBuffer.byteOffset, inputBuffer.byteLength);

    const topBoxes = parseBoxes(buf, 0, buf.length);
    const ftyp = topBoxes.find(b => b.type === 'ftyp');
    const moov = topBoxes.find(b => b.type === 'moov');
    const mdat = topBoxes.find(b => b.type === 'mdat');

    if (!ftyp || !moov || !mdat) {
        throw new Error('Missing standard MP4 boxes (ftyp, moov, mdat).');
    }

    const ftypBytes = buf.slice(ftyp.offset, ftyp.end);
    const origMdatPayload = buf.slice(mdat.contentStart, mdat.end);
    const origMdatContentStart = mdat.contentStart;

    const moovChildren = parseBoxes(buf, moov.contentStart, moov.end);
    const mvhd = moovChildren.find(b => b.type === 'mvhd');
    const traks = moovChildren.filter(b => b.type === 'trak');

    if (!mvhd || traks.length === 0) {
        throw new Error('Invalid moov structure: mvhd or trak missing.');
    }

    const origMvhdVer = buf[mvhd.contentStart];
    const origMvhdTimescale = readU32(buf, mvhd.contentStart + (origMvhdVer === 1 ? 20 : 12)) || 1000;
    const targetTimescale = 48000;

    function rescaleDuration(val) {
        if (!val || val === 0) return 0;
        return Math.round((Number(val) * targetTimescale) / origMvhdTimescale);
    }

    function rescaleTkhd(tkhdBox) {
        const payload = Buffer.from(buf.slice(tkhdBox.contentStart, tkhdBox.end));
        const ver = payload[0];
        const durOffset = ver === 1 ? 24 : 20;
        const origDur = ver === 1 ? payload.readBigUInt64BE(durOffset) : payload.readUInt32BE(durOffset);
        const newDur = rescaleDuration(origDur);
        if (ver === 1) {
            payload.writeBigUInt64BE(BigInt(newDur), durOffset);
        } else {
            payload.writeUInt32BE(newDur >>> 0, durOffset);
        }
        return makeBox('tkhd', payload);
    }

    function rescaleEdts(edtsBox) {
        const elstBox = findDeep(buf, edtsBox.contentStart, edtsBox.end, 'elst');
        if (!elstBox) return buf.slice(edtsBox.offset, edtsBox.end);
        const elstPayload = Buffer.from(buf.slice(elstBox.contentStart, elstBox.end));
        const ver = elstPayload[0];
        const entryCount = elstPayload.readUInt32BE(4);
        let cur = 8;
        for (let i = 0; i < entryCount; i++) {
            if (ver === 1) {
                const segDur = elstPayload.readBigUInt64BE(cur);
                elstPayload.writeBigUInt64BE(BigInt(rescaleDuration(segDur)), cur);
                cur += 8 + 8 + 4;
            } else {
                const segDur = elstPayload.readUInt32BE(cur);
                elstPayload.writeUInt32BE(rescaleDuration(segDur) >>> 0, cur);
                cur += 4 + 4 + 4;
            }
        }
        const newElstBox = makeBox('elst', elstPayload);
        return makeBox('edts', newElstBox);
    }

    // 1. mvhd Version 1 (64-bit), timescale 48000, infinite duration
    const newMvhdPayload = Buffer.alloc(112);
    newMvhdPayload[0] = 1;
    newMvhdPayload.writeBigUInt64BE(0n, 4);  // creation_time
    newMvhdPayload.writeBigUInt64BE(0n, 12); // modification_time
    newMvhdPayload.writeUInt32BE(targetTimescale, 20); // timescale = 48000
    newMvhdPayload.writeBigUInt64BE(0xFFFFFFFFFFFFFFFFn, 24); // duration infinite
    newMvhdPayload.writeUInt32BE(0x00010000, 32); // rate 1.0
    newMvhdPayload.writeUInt16BE(0x0100, 36);     // volume 1.0
    newMvhdPayload.writeUInt32BE(0x00010000, 48); // unity matrix
    newMvhdPayload.writeUInt32BE(0x00010000, 64);
    newMvhdPayload.writeUInt32BE(0x40000000, 80);
    newMvhdPayload.writeUInt32BE(traks.length > 1 ? 3 : 2, 108); // next_track_id
    const newMvhdBox = makeBox('mvhd', newMvhdPayload);

    const videoTrak = traks[0];
    const audioTrak = traks.length > 1 ? traks[1] : null;

    const vSttsBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'stts');
    const vStscBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'stsc');
    const vStszBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'stsz');
    const vStcoBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'stco') || findDeep(buf, videoTrak.contentStart, videoTrak.end, 'co64');

    if (!vSttsBox || !vStscBox || !vStszBox || !vStcoBox) {
        throw new Error('Video stbl table boxes not found.');
    }

    const vChunkCount = readU32(buf, vStcoBox.contentStart + 4);
    const vRelOffsets = [];
    for (let i = 0; i < vChunkCount; i++) {
        const off = readU32(buf, vStcoBox.contentStart + 8 + i * 4);
        vRelOffsets.push(off - origMdatContentStart);
    }

    let aStcoBox = null;
    let aChunkCount = 0;
    const aRelOffsets = [];
    if (audioTrak) {
        aStcoBox = findDeep(buf, audioTrak.contentStart, audioTrak.end, 'stco') || findDeep(buf, audioTrak.contentStart, audioTrak.end, 'co64');
        if (aStcoBox) {
            aChunkCount = readU32(buf, aStcoBox.contentStart + 4);
            for (let i = 0; i < aChunkCount; i++) {
                const off = readU32(buf, aStcoBox.contentStart + 8 + i * 4);
                aRelOffsets.push(off - origMdatContentStart);
            }
        }
    }

    // 8-byte in-mdat anchor (clean ISO free atom, di DALAM mdat)
    const inMdatAnchor = Buffer.from([0x00, 0x00, 0x00, 0x08, 0x66, 0x72, 0x65, 0x65]);

    // Video STTS (+1 zero-delta sample minimum)
    const origVSttsEntries = readU32(buf, vSttsBox.contentStart + 4);
    const newVSttsPayload = Buffer.alloc(8 + (origVSttsEntries + 1) * 8);
    newVSttsPayload.writeUInt32BE(origVSttsEntries + 1, 4);
    buf.copy(newVSttsPayload, 8, vSttsBox.contentStart + 8, vSttsBox.contentStart + 8 + origVSttsEntries * 8);
    newVSttsPayload.writeUInt32BE(1, 8 + origVSttsEntries * 8);
    newVSttsPayload.writeUInt32BE(0, 8 + origVSttsEntries * 8 + 4);
    const newVSttsBox = makeBox('stts', newVSttsPayload);

    // Video STSZ (+1 sample of size 8)
    const origVSampleSize = readU32(buf, vStszBox.contentStart + 4);
    const origVSampleCount = readU32(buf, vStszBox.contentStart + 8);
    const newVStszPayload = Buffer.alloc(12 + (origVSampleCount + 1) * 4);
    newVStszPayload.writeUInt32BE(0, 4);
    newVStszPayload.writeUInt32BE(origVSampleCount + 1, 8);
    if (origVSampleSize === 0) {
        buf.copy(newVStszPayload, 12, vStszBox.contentStart + 12, vStszBox.contentStart + 12 + origVSampleCount * 4);
    } else {
        for (let i = 0; i < origVSampleCount; i++) {
            newVStszPayload.writeUInt32BE(origVSampleSize, 12 + i * 4);
        }
    }
    newVStszPayload.writeUInt32BE(8, 12 + origVSampleCount * 4);
    const newVStszBox = makeBox('stsz', newVStszPayload);

    // Video STSC (+1 chunk)
    const origVStscEntries = readU32(buf, vStscBox.contentStart + 4);
    const newVStscPayload = Buffer.alloc(8 + (origVStscEntries + 1) * 12);
    newVStscPayload.writeUInt32BE(origVStscEntries + 1, 4);
    buf.copy(newVStscPayload, 8, vStscBox.contentStart + 8, vStscBox.contentStart + 8 + origVStscEntries * 12);
    newVStscPayload.writeUInt32BE(vChunkCount + 1, 8 + origVStscEntries * 12);
    newVStscPayload.writeUInt32BE(1, 8 + origVStscEntries * 12 + 4);
    newVStscPayload.writeUInt32BE(1, 8 + origVStscEntries * 12 + 8);
    const newVStscBox = makeBox('stsc', newVStscPayload);

    const vStblBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'stbl');
    const vStblChildren = parseBoxes(buf, vStblBox.contentStart, vStblBox.end);
    const vMinfBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'minf');
    const vMinfChildren = parseBoxes(buf, vMinfBox.contentStart, vMinfBox.end);
    const vMdiaBox = findDeep(buf, videoTrak.contentStart, videoTrak.end, 'mdia');
    const vMdiaChildren = parseBoxes(buf, vMdiaBox.contentStart, vMdiaBox.end);
    const vTrakChildren = parseBoxes(buf, videoTrak.contentStart, videoTrak.end);

    let moovBytes = null;
    let finalOutput = null;

    for (let iter = 0; iter < 3; iter++) {
        const estMoovLen = moovBytes ? moovBytes.length : (moov.size + 1024);
        const newMdatContentStart = ftypBytes.length + estMoovLen + 8;
        const anchorChunkOffset = newMdatContentStart + origMdatPayload.length;

        // Video STCO (+1 chunk = in-mdat anchor)
        const newVStcoPayload = Buffer.alloc(8 + (vChunkCount + 1) * 4);
        newVStcoPayload.writeUInt32BE(vChunkCount + 1, 4);
        for (let i = 0; i < vChunkCount; i++) {
            newVStcoPayload.writeUInt32BE(vRelOffsets[i] + newMdatContentStart, 8 + i * 4);
        }
        newVStcoPayload.writeUInt32BE(anchorChunkOffset, 8 + vChunkCount * 4);
        const newVStcoBox = makeBox('stco', newVStcoPayload);

        // Reassemble Video STBL (TIDAK ada ctts injection)
        const vStblParts = [];
        for (const child of vStblChildren) {
            if (child.type === 'stts') vStblParts.push(newVSttsBox);
            else if (child.type === 'ctts') vStblParts.push(buf.slice(child.offset, child.end));
            else if (child.type === 'stsc') vStblParts.push(newVStscBox);
            else if (child.type === 'stsz') vStblParts.push(newVStszBox);
            else if (child.type === 'stco' || child.type === 'co64') vStblParts.push(newVStcoBox);
            else vStblParts.push(buf.slice(child.offset, child.end));
        }
        const newVStbl = makeBox('stbl', Buffer.concat(vStblParts));

        const vMinfParts = [];
        for (const child of vMinfChildren) {
            if (child.type === 'stbl') vMinfParts.push(newVStbl);
            else vMinfParts.push(buf.slice(child.offset, child.end));
        }
        const newVMinf = makeBox('minf', Buffer.concat(vMinfParts));

        const vMdiaParts = [];
        for (const child of vMdiaChildren) {
            if (child.type === 'minf') vMdiaParts.push(newVMinf);
            else vMdiaParts.push(buf.slice(child.offset, child.end));
        }
        const newVMdia = makeBox('mdia', Buffer.concat(vMdiaParts));

        // Reassemble Video Trak
        const vTrakParts = [];
        for (const child of vTrakChildren) {
            if (child.type === 'tkhd') vTrakParts.push(rescaleTkhd(child));
            else if (child.type === 'edts') vTrakParts.push(rescaleEdts(child));
            else if (child.type === 'mdia') vTrakParts.push(newVMdia);
            else vTrakParts.push(buf.slice(child.offset, child.end));
        }
        const newVTrak = makeBox('trak', Buffer.concat(vTrakParts));

        let newATrak = null;
        if (audioTrak) {
            const aStblBox = findDeep(buf, audioTrak.contentStart, audioTrak.end, 'stbl');
            const aStblChildren = parseBoxes(buf, aStblBox.contentStart, aStblBox.end);
            const aMinfBox = findDeep(buf, audioTrak.contentStart, audioTrak.end, 'minf');
            const aMinfChildren = parseBoxes(buf, aMinfBox.contentStart, aMinfBox.end);
            const aMdiaBox = findDeep(buf, audioTrak.contentStart, audioTrak.end, 'mdia');
            const aMdiaChildren = parseBoxes(buf, aMdiaBox.contentStart, aMdiaBox.end);
            const aTrakChildren = parseBoxes(buf, audioTrak.contentStart, audioTrak.end);

            const newAStcoPayload = Buffer.alloc(8 + aChunkCount * 4);
            newAStcoPayload.writeUInt32BE(aChunkCount, 4);
            for (let i = 0; i < aChunkCount; i++) {
                newAStcoPayload.writeUInt32BE(aRelOffsets[i] + newMdatContentStart, 8 + i * 4);
            }
            const newAStcoBox = makeBox('stco', newAStcoPayload);

            const aStblParts = [];
            for (const child of aStblChildren) {
                if (child.type === 'stco' || child.type === 'co64') aStblParts.push(newAStcoBox);
                else aStblParts.push(buf.slice(child.offset, child.end));
            }
            const newAStbl = makeBox('stbl', Buffer.concat(aStblParts));

            const aMinfParts = [];
            for (const child of aMinfChildren) {
                if (child.type === 'stbl') aMinfParts.push(newAStbl);
                else aMinfParts.push(buf.slice(child.offset, child.end));
            }
            const newAMinf = makeBox('minf', Buffer.concat(aMinfParts));

            const aMdiaParts = [];
            for (const child of aMdiaChildren) {
                if (child.type === 'minf') aMdiaParts.push(newAMinf);
                else aMdiaParts.push(buf.slice(child.offset, child.end));
            }
            const newAMdia = makeBox('mdia', Buffer.concat(aMdiaParts));

            const aTrakParts = [];
            for (const child of aTrakChildren) {
                if (child.type === 'tkhd') aTrakParts.push(rescaleTkhd(child));
                else if (child.type === 'edts') aTrakParts.push(rescaleEdts(child));
                else if (child.type === 'mdia') aTrakParts.push(newAMdia);
                else aTrakParts.push(buf.slice(child.offset, child.end));
            }
            newATrak = makeBox('trak', Buffer.concat(aTrakParts));
        }

        const moovChildrenBoxes = [newMvhdBox, newVTrak];
        if (newATrak) moovChildrenBoxes.push(newATrak);

        // Retain original udta if present
        const udta = moovChildren.find(b => b.type === 'udta');
        if (udta) {
            moovChildrenBoxes.push(buf.slice(udta.offset, udta.end));
        }

        moovBytes = makeBox('moov', Buffer.concat(moovChildrenBoxes));

        const updatedMdatStart = ftypBytes.length + moovBytes.length + 8;
        if (Math.abs(updatedMdatStart - newMdatContentStart) === 0 || iter === 2) {
            const finalMdatPayload = Buffer.concat([origMdatPayload, inMdatAnchor]);
            const newMdatBox = makeBox('mdat', finalMdatPayload);
            // STRICT ISO: ftyp → moov → mdat (tidak ada byte di luar mdat)
            finalOutput = Buffer.concat([ftypBytes, moovBytes, newMdatBox]);
            break;
        }
    }

    return finalOutput;
}

function patchAv1SentinelUltimate(inputMp4Path, outputMp4Path) {
    const buf = fs.readFileSync(inputMp4Path);
    const patched = patchAv1SentinelUltimateBuffer(buf);
    fs.writeFileSync(outputMp4Path, patched);
    return outputMp4Path;
}

module.exports = {
    patchAv1SentinelUltimate,
    patchAv1SentinelUltimateBuffer
};
