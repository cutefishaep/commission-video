# RawTik Lite

Compact ISOBMFF method maker for TikTok direct pass-through bypass.

## Quick Start

```bash
python main.py -m av1-sentinel-ultimate -i input/input.mp4 -o output/output.mp4
```

## Structure

```
RawTik Lite/
├── main.py          # Patch + upload + CDN verify + delete
├── methods/         # Method JS patchers
│   └── av1Sentinel-Ultimate.js  # WORK - 1080p60 PASS
├── tools/           # Empty (auto-download tools as needed)
├── input/           # Put test video here
└── output/          # Patched video + results
```

## Working Method

- `av1-sentinel-ultimate` — Minimal manipulation, no CTTS, no comment box, pure 2-track. Verified 1080p60 direct pass-through.

## Cookie

Cookie required in `.env` or prompted at first run:

```
TIKTOK_ACCOUNT=cutefishaep
TIKTOK_COOKIE=[{"name":"sessionid","value":"xxx",...}]
```

Get cookies via extension: https://chromewebstore.google.com/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc

## Principle

Minimal MP4 box manipulation only — no re-encode, no Track 3 trap, no bytes outside mdat, FTYP unchanged.

## Analyzing Working Method → Making New Method (Rules)

When creating a new method, analyze the working `av1Sentinel-Ultimate.js` first. Follow these rules:

### ✅ ALLOWED (keep these)
- `mvhd` Version 1 (64-bit), timescale 48000 or 90000, duration `0xFFFFFFFFFFFFFFFF` (infinite)
- Pure 2-track only: Track 1 video + Track 2 audio
- `tkhd`/`elst` rescale duration from original timescale → target timescale
- Video `stts` +1 zero-delta sample, `stsz` +1 sample size 8, `stsc` +1 chunk, `stco` +1 chunk (anchor inside mdat)
- `ctts` flat zero-offset (optional — can be omitted)
- Retain original `udta` box
- `©cmt` comment box inside `udta` (optional)
- Early break when `stco` offset converges (don't force 3 iterations)
- Output structure: `ftyp → moov → mdat` strictly (no bytes after mdat)
- FTYP unchanged

### ❌ AVOID (these cause FAIL / crash)
- **Track 3 / third track / auxiliary track / dummy audio / micro-shield** → detected as manipulated → 720p transcode
- **Bytes outside mdat / trailing bytes / post-mdat trap / outMdatTrap** → non-standard ISO → transcode
- **FTYP brand change** (e.g., to 'av01') → browser crash on upload
- **STSS ghost entry / fake sync sample / phantom sample** → transcode
- **Over-engineering** / too many box modifications → transcode

### Keyword Checklist (grep your new method)

Before testing, grep your `.js` method file. If any AVOID keyword appears, remove it:

```
grep -i "track 3\|t3trak\|auxiliary\|micro-shield\|dummy audio\|outmdattrap\|trailing\|av01\|ftyp.*brand\|stss.*ghost" methods/your-method.js
```

If clean, the method has a high chance of PASS 1080p60.

### Working Method Reference

`av1Sentinel-Ultimate.js` is the baseline. It is the most minimal version that passes 1080p60. Any new method should be **equal or simpler** than this.
