#!/usr/bin/env python3
"""RawTik Lite - Compact ISOBMFF method maker for TikTok direct pass-through."""
import os, sys, json, argparse, subprocess, datetime
from pathlib import Path

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8")
    except Exception: pass

from tools.config import load_or_prompt_cookie

RESULTS_PATH = Path("output/method_results.json")
MAX_HISTORY = 10

def save_result(method, post_url, stats):
    entry = {"saved_at": datetime.datetime.now().isoformat(timespec="seconds"),
             "post_url": post_url, "cdn": {"width": stats.get("width"), "height": stats.get("height"),
                                          "fps": stats.get("fps"), "bitrateMbps": stats.get("bitrateMbps"),
                                          "sizeMb": stats.get("sizeMb")},
             "stream_url": stats.get("videoStreamUrl")}
    data = {}
    if RESULTS_PATH.exists():
        try: data = json.loads(RESULTS_PATH.read_text(encoding="utf-8"))
        except Exception: data = {}
    rec = data.setdefault(method, {"status": "SUCCESS", "last_verified": None, "history": []})
    rec["status"] = "SUCCESS"; rec["last_verified"] = entry
    rec["history"] = [entry] + rec.get("history", [])[:MAX_HISTORY - 1]
    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def analyze(url):
    from tools.analyze import analyze_tiktok_url
    return analyze_tiktok_url(url)

def main():
    p = argparse.ArgumentParser(description="RawTik Lite")
    p.add_argument("-m", "--method", default="av1-sentinel-ultimate")
    p.add_argument("-i", "--input", default="input/input.mp4")
    p.add_argument("-o", "--output", default="")
    p.add_argument("--skip-upload", action="store_true")
    p.add_argument("--no-delete", action="store_true")
    p.add_argument("--analyze-only", default="")
    a = p.parse_args()

    if a.analyze_only:
        try:
            s = analyze(a.analyze_only)
            short = min(s.get("width",0), s.get("height",0))
            print(f"[HASIL] method : {a.analyze_only}")
            print(f"[HASIL] CDN    : {s.get('width')}x{s.get('height')} @ {s.get('fps')} fps")
            print(f"[HASIL] verdict: {'PASS' if short>=1080 and s.get('fps',0)>=58 else 'FAIL'}")
        except Exception as e: print(f"[Analyze Error] {e}")
        return

    if not Path(a.input).exists():
        print(f"[Error] Input not found: {a.input}"); sys.exit(1)
    out = a.output or f"output/output_{a.method}.mp4"
    Path(out).parent.mkdir(parents=True, exist_ok=True)

    print(f"\n[RawTik Lite] Patch: {a.method} | {a.input} -> {out}\n")
    patcher = Path("tools/patcher.js")
    r = subprocess.run(["node", str(patcher), a.method, a.input, out])
    if r.returncode != 0:
        print("[Error] Patch failed."); sys.exit(1)

    if a.skip_upload:
        print(f"[RawTik Lite] Done. Output: {out}"); return

    cookies = load_or_prompt_cookie()
    from tools.uploader import run_pipeline
    try:
        res = run_pipeline(out, cookies, delete=not a.no_delete)
    except Exception as e:
        print(f"[Pipeline Error] {e}"); sys.exit(1)

    if res.get("error"):
        print(f"[Pipeline] {res['error']}"); sys.exit(1)

    s = res.get("stats"); passed = False
    if s:
        short = min(s.get("width",0), s.get("height",0))
        passed = short >= 1080 and s.get("fps",0) >= 58
        print(f"[HASIL] method : {a.method}")
        print(f"[HASIL] CDN    : {s.get('width')}x{s.get('height')} @ {s.get('fps')} fps")
        print(f"[HASIL] verdict: {'PASS - direct pass-through' if passed else 'FAIL - transcoded'}")
    if passed and s:
        save_result(a.method, res.get("url",""), s)
        print(f"[RawTik Lite] Method '{a.method}' validated and saved.")
    print("[RawTik Lite] Session finished.")

if __name__ == "__main__": main()
