"""
tools/analyze.py - Live CDN Stream Inspector (Python murni, TANPA node/js).

Alur:
1. Resolve post TikTok via API tikwm.com (hdplay/play/wmplay).
2. Download header stream (~512 KB pertama) ke temp/ (otomatis dibersihkan).
3. Parse atom MP4 binary lokal:
   - tkhd  -> resolusi (width/height)
   - mdhd  -> timescale video track
   - stts  -> sample delta pertama
   fps = round(timescale / sample_delta)

Return dict yang fields-nya identik dengan versi lama analyze.js:
{postUrl, author, title, duration, width, height, fps, sizeBytes, sizeMb, bitrateMbps, videoStreamUrl}
"""

import json
import shutil
from pathlib import Path

import requests

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
TEMP_DIR = Path(__file__).resolve().parent.parent / "temp"


def resolve_post(post_url: str) -> dict:
    """Resolve info postingan TikTok via tikwm.com (gratis, tanpa key)."""
    r = requests.get("https://www.tikwm.com/api/", params={"url": post_url}, headers=UA, timeout=30)
    r.raise_for_status()
    j = r.json()
    if j.get("code") != 0 or not j.get("data"):
        raise RuntimeError(j.get("msg") or "Gagal meresolve video TikTok (tikwm).")
    return j["data"]


def download_stream_head(url: str, dest: Path, max_bytes: int = 524288, headers=None) -> int:
    """Download N byte pertama stream (Range request). Return jumlah byte didapat."""
    req_headers = {**UA, "Range": f"bytes=0-{max_bytes - 1}"}
    if headers:
        req_headers.update(headers)
    with requests.get(url, headers=req_headers, stream=True, timeout=60) as r:
        r.raise_for_status()
        downloaded = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                f.write(chunk)
                downloaded += len(chunk)
                if downloaded >= max_bytes:
                    break
    return downloaded


def _u32(buf: bytes, off: int) -> int:
    return int.from_bytes(buf[off:off + 4], "big")


def parse_fps_resolution(path: Path) -> dict:
    """
    Scan byte-per-byte mencari atom tkhd / handler 'vide' -> mdhd/stts.
    Port 1:1 dari parseFpsAndResolutionFromFile di analyze.js lama.
    """
    buf = path.read_bytes()
    data = len(buf) - 8
    width = height = 0
    timescale = 0
    sample_delta = 0

    for i in range(data):
        if buf[i:i + 4] == b"tkhd":
            ver = buf[i + 4]
            w = _u32(buf, i + (92 if ver == 1 else 80)) >> 16
            h = _u32(buf, i + (96 if ver == 1 else 84)) >> 16
            if w > 0 and h > 0 and not width:
                width, height = w, h

        elif buf[i:i + 4] == b"vide":
            search_end = min(len(buf), i + 8000) - 8
            for j in range(max(0, i - 300), search_end):
                if buf[j:j + 4] == b"mdhd":
                    version = buf[j + 4]
                    timescale = _u32(buf, j + (24 if version == 1 else 16))
                elif buf[j:j + 4] == b"stts":
                    entry_count = _u32(buf, j + 8)
                    if entry_count > 0:
                        sample_delta = _u32(buf, j + 16)
                if timescale and sample_delta:
                    break

    fps = round(timescale / sample_delta) if timescale and sample_delta else 0
    return {"fps": fps, "width": width, "height": height}


def analyze_tiktok_url(post_url: str) -> dict:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    temp_file = TEMP_DIR / f"stream_{int(__import__('time').time() * 1000)}.mp4"

    try:
        data = resolve_post(post_url)

        stream_url = data.get("hdplay") or data.get("play") or data.get("wmplay")
        if not stream_url:
            raise RuntimeError("Tidak ditemukan URL stream playback.")

        download_stream_head(stream_url, temp_file, 524288)
        specs = parse_fps_resolution(temp_file)

        duration_sec = float(data.get("duration") or 0)
        size_bytes = int(data.get("size") or 0)
        size_mb = round(size_bytes / (1024 * 1024), 2)
        bitrate_mbps = round((size_bytes * 8) / (duration_sec * 1_000_000), 2) if (duration_sec > 0 and size_bytes > 0) else 0

        author = "-"
        if isinstance(data.get("author"), dict):
            author = data["author"].get("unique_id") or author
        author = data.get("author_unique_id") or author

        return {
            "postUrl": post_url,
            "author": author,
            "title": data.get("title") or "",
            "duration": duration_sec,
            "width": specs["width"] or int(data.get("width") or 0),
            "height": specs["height"] or int(data.get("height") or 0),
            "fps": specs["fps"],
            "sizeBytes": size_bytes,
            "sizeMb": size_mb,
            "bitrateMbps": bitrate_mbps,
            "videoStreamUrl": stream_url,
        }
    finally:
        # Selalu bersihkan temp dir beserta isinya
        shutil.rmtree(TEMP_DIR, ignore_errors=True)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python analyze.py <tiktok_post_url>")
        sys.exit(1)
    try:
        print(json.dumps(analyze_tiktok_url(sys.argv[1]), indent=2))
    except Exception as e:
        print(f"[Analyzer Error] {e}")
        sys.exit(1)
